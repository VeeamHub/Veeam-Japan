//Proof of Concept by Tats@Veeam Japan
//Chrome Extension to internationalize VSPC web UI - starting with Japanese. 

//At Beta stages, will
	//1. include instructions and supporting Excel dictionary file to make this applicable to any language of choice
	//2. cleanse comments (ie my struggles..)

//At RC stages, will
	//1. modify manifest file for better security

//Revision History
	//v0.1- works but is buggy when moving to other tabs- this is due to the design of Single Page Applications
	//v0.2- now better with SPA's - added listening for hashchange events
	//v0.3- added dictionary terms | still need to optimize for Single Page Applicaitons as RegEx is taking too long to execute
	//v0.4- added dictionary terms | RegEx is slower - StackOverflow and ChatGPT helping for more effiecient coding
	//v0.5- ok my programming skill is too lame to make partial improvements - may be the limit of coding by (albiet super geeky) sales leader

//Known issues
	//as #of RegEx replacements increase, script takes more time to walk through and replace - so sometimes some words are not translated in time. Will need to come up with different approach to make this more efficient.

//Am thinking...1-instead of replace(), use string.prototype.replace() 2- use data structure like Map to store, then may be able to look up in constant time instead of using a switch statement.

//=========
// Listen for hashchange events (Tats-added b/c SPA URLs don't change beyond #, and script thinks load is change in URL...)
// 
window.addEventListener('hashchange', function() {
  // When the hash changes, re-run the walk function on the document body
  walk(document.body);
});

// Listen for page load events (Tats-don't know if I still need this...page loads once but due to SPA behavior-running once on load doesn't mean much)
window.addEventListener('load', function() {
  // When the page loads, run the walk function on the document body
  walk(document.body);
});

// Create a MutationObserver that listens for changes to the body element
var observer = new MutationObserver(function(mutations) {
  // When the body element changes, re-run the walk function on the document body
  mutations.forEach(function(mutation) {
    walk(document.body);
  });
});

// Only listen for changes to the body element, not all child nodes
var observerConfig = {
  childList: true,
};

// Schedule the walk function to run every 5 seconds
setInterval(function() {
  walk(document.body);
}, 5000);

// Observe the body element
var targetNode = document.body;
observer.observe(targetNode, observerConfig);

function walk(node) 
{
	var ignore = { "STYLE":0, "SCRIPT":0, "NOSCRIPT":0, "IFRAME":0, "OBJECT":0 }
	// I stole this function from here:
	// http://is.gd/mwZp7E
	
	var child, next;
	
if (node.nodeName.toLowerCase() == 'input' || node.nodeName.toLowerCase() == 'textarea' || (node.classList && node.classList.contains('ace_editor'))) { return; }

	if (node.tagName in ignore) return;
	
	switch ( node.nodeType )  
	{
		case 1:  // Element
		case 9:  // Document
		case 11: // Document fragment
			child = node.firstChild;
			while ( child ) 
			{
				next = child.nextSibling;
				walk(child);
				child = next;
			}
			break;

		case 3: // Text node
			handleText(node);
			break;
	}
}
function handleText(textNode) 
{

	var v = textNode.nodeValue;

// Copy paste dictionary from external Excel
// Basic idea of Excel - Column A has English string. Column B has translated language string. In Column C, concatenate the following 5 elements: 1) v = v.replace(/\ 2) {English string} 3) \b/igm, " 4) {Translated string} 5)");
// Column C then look like below - a bunch of RegEx, which you would add to this list for JP, or replace if for other language.
v = v.replace(/\Sites\b/igm, "サイト");
v = v.replace(/\Monitoring\b/igm, "モニタリング");
v = v.replace(/\Clients Overview\b/igm, "顧客サマリー");
v = v.replace(/\Dashboards\b/igm, "ダッシュボード");
v = v.replace(/\Active Alarms\b/igm, "アクティブアラーム");
v = v.replace(/\Top Companies\b/igm, "上位顧客");
v = v.replace(/\Management\b/igm, "管理");
v = v.replace(/\Backup Jobs\b/igm, "バックアップジョブ");
v = v.replace(/\Failover Plans\b/igm, "フェールオーバープラン");
v = v.replace(/\Protected Data\b/igm, "保護データ");
v = v.replace(/\Clients\b/igm, "クライアント");
v = v.replace(/\Companies\b/igm, "顧客");
v = v.replace(/\Resellers\b/igm, "リセラー");
v = v.replace(/\Discovery\b/igm, "ディスカバリー");
v = v.replace(/\Reporting\b/igm, "レポーティング");
v = v.replace(/\Billing Summary\b/igm, "請求サマリー");
v = v.replace(/\Invoices\b/igm, "請求書");
v = v.replace(/\Reports\b/igm, "レポート");
v = v.replace(/\Client Alarms\b/igm, "顧客アラーム");
v = v.replace(/\Monthly Revenue\b/igm, "月間売上");
v = v.replace(/\Protected VMs\b/igm, "保護VM数");
v = v.replace(/\Protected Computers\b/igm, "保護コンピュータ数");
v = v.replace(/\Cloud Replicas\b/igm, "クラウドレプリカ");
v = v.replace(/\Cloud Backups\b/igm, "クラウドバックアップ");
v = v.replace(/\Protected Files\b/igm, "保護ファイル");
v = v.replace(/\Company\b/igm, "顧客");
v = v.replace(/\Backup Agents\b/igm, "エージェント");
v = v.replace(/\Protected VMs\b/igm, "保護VM");
v = v.replace(/\VMs in Cloud\b/igm, "クラウド上のVM");
v = v.replace(/\Agents in Cloud\b/igm, "クラウド上のエージェント");
v = v.replace(/\Active Alarms\b/igm, "アクティブアラーム");
v = v.replace(/\Protected Files\b/igm, "保護ファイル");
v = v.replace(/\Last Active Date\b/igm, "最終アクティブ日時");
v = v.replace(/\Jobs Overview\b/igm, "ジョブ概要");
v = v.replace(/\Backup Infrastructure\b/igm, "バックアップ基盤");
v = v.replace(/\Cloud Connect Infrastructure\b/igm, "クラウドコネクトインフラストラクチャ");
v = v.replace(/\Sunday\b/igm, "日曜日");
v = v.replace(/\Monday\b/igm, "月曜日");
v = v.replace(/\Tuesday\b/igm, "火曜日");
v = v.replace(/\Wednesday\b/igm, "水曜日");
v = v.replace(/\Thursday\b/igm, "木曜日");
v = v.replace(/\Friday\b/igm, "金曜日");
v = v.replace(/\Saturday\b/igm, "土曜日");
v = v.replace(/\Failed\b/igm, "失敗");
v = v.replace(/\Warning\b/igm, "警告");
v = v.replace(/\Success\b/igm, "成功");
v = v.replace(/\Period\b/igm, "期間");
v = v.replace(/\Last 30 days\b/igm, "過去30日");
v = v.replace(/\Current Month\b/igm, "当月");
v = v.replace(/\Previous Month\b/igm, "前月");
v = v.replace(/\Site\b/igm, "サイト");
v = v.replace(/\Max \b/igm, "最大 ");
v = v.replace(/\Computers\b/igm, "コンピュータ");
v = v.replace(/\Virtual Machines\b/igm, "仮想マシン");
v = v.replace(/\File Shares\b/igm, "ファイル共有");
v = v.replace(/\Managed by Console\b/igm, "コンソールで管理");
v = v.replace(/\Managed by Backup Server\b/igm, "バックアップサーバーで管理");
v = v.replace(/\Start\b/igm, "開始");
v = v.replace(/\Stop\b/igm, "停止");
v = v.replace(/\Create Job\b/igm, "ジョブの作成");
v = v.replace(/\Agent UI Mode\b/igm, "エージェントUIモード");
v = v.replace(/\Switch to Read-only UI\b/igm, "リードオンリーUIに切り替える");
v = v.replace(/\Switch to Full Admin Access\b/igm, "フル管理者アクセスに切り替える");
v = v.replace(/\Scheduling\b/igm, "スケジューリング");
v = v.replace(/\Enable\b/igm, "有効にする");
v = v.replace(/\Disable\b/igm, "無効にする");
v = v.replace(/\Settings\b/igm, "設定項目");
v = v.replace(/\Other Actions\b/igm, "その他の操作");
v = v.replace(/\Download logs\b/igm, "ログをダウンロードする");
v = v.replace(/\Export to\b/igm, "エクスポート先");
v = v.replace(/\Job Status:\b/igm, "ジョブの状態");
v = v.replace(/\All\b/igm, "すべて");
v = v.replace(/\Filter (None)\b/igm, "フィルター (なし)");
v = v.replace(/\Computer\b/igm, "コンピュータ");
v = v.replace(/\Tag\b/igm, "タグ");
v = v.replace(/\Operation Mode\b/igm, "動作モード");
v = v.replace(/\Running Jobs\b/igm, "実行中のジョブ");
v = v.replace(/\Successful Jobs\b/igm, "成功したジョブ");
v = v.replace(/\Backup Policy\b/igm, "バックアップポリシー");
v = v.replace(/\UI Mode\b/igm, "UIモード");
v = v.replace(/\Agent Version\b/igm, "エージェントバージョン");
v = v.replace(/\Status:\b/igm, "ステータス");
v = v.replace(/\Type:\b/igm, "タイプ");
v = v.replace(/\Resolve\b/igm, "解決する");
v = v.replace(/\Acknolwedge Alarm\b/igm, "アラームの解除");
v = v.replace(/\Delete Alarm\b/igm, "アラームの削除");
v = v.replace(/\Status\b/igm, "状態");
v = v.replace(/\Time\b/igm, "時間");
v = v.replace(/\Alarm\b/igm, "アラーム");
v = v.replace(/\Object\b/igm, "オブジェクト");
v = v.replace(/\N. of Repeats\b/igm, "繰り返し回数");
v = v.replace(/\Upload\b/igm, "アップロード");
v = v.replace(/\Download\b/igm, "ダウンロード");
v = v.replace(/\Total\b/igm, "合計");
v = v.replace(/\VMs in the Cloud Repository\b/igm, "クラウドリポジトリのVM");
v = v.replace(/\Data Transfer Out\b/igm, "データ転送終了");
v = v.replace(/\Start\b/igm, "開始");
v = v.replace(/\Failover Plan\b/igm, "フェイルオーバー計画");
v = v.replace(/\Server\b/igm, "サーバー");
v = v.replace(/\Company\b/igm, "会社");
v = v.replace(/\Site\b/igm, "サイト");
v = v.replace(/\Location\b/igm, "ロケーション");
v = v.replace(/\VMs\b/igm, "VMs");
v = v.replace(/\Type\b/igm, "タイプ");
v = v.replace(/\Undo\b/igm, "取り消し");
v = v.replace(/\Name\b/igm, "名称");
v = v.replace(/\Backups\b/igm, "バックアップ");
v = v.replace(/\Backup Copies\b/igm, "バックアップコピー");
v = v.replace(/\Guest OS\b/igm, "ゲストOS");
v = v.replace(/\Latest Restore Point\b/igm, "最新リストアポイント");
v = v.replace(/\Last Heartbeat\b/igm, "最後のハートビート");
v = v.replace(/\Configuration\b/igm, "設定");
v = v.replace(/\Please wait\b/igm, "ロード中");
v = v.replace(/\Please log in\b/igm, "ログインしてください");
v = v.replace(/\Log in\b/igm, "ログイン");
v = v.replace(/\Forgot password?\b/igm, "パスワードをお忘れですか？");
v = v.replace(/\Cloud Copy\b/igm, "クラウドコピー");
v = v.replace(/\New\b/igm, "新規作成");
v = v.replace(/\Edit\b/igm, "編集");
v = v.replace(/\Remove\b/igm, "削除");
v = v.replace(/\Manage\b/igm, "管理");
v = v.replace(/\Locations\b/igm, "ロケーション");
v = v.replace(/\Users\b/igm, "ユーザー");
v = v.replace(/\Set Billing\b/igm, "請求設定");
v = v.replace(/\Reset Security Token\b/igm, "セキュリティトークンのリセット");
v = v.replace(/\Send Welcome Email\b/igm, "開通メールを送信");
v = v.replace(/\Enforce\b/igm, "強制");
v = v.replace(/\Ignore\b/igm, "無視");
v = v.replace(/\Administrators\b/igm, "管理者");
v = v.replace(/\Portal Users\b/igm, "ポータルユーザ");
v = v.replace(/\Lease Expiration Date\b/igm, "リース期限");
v = v.replace(/\State\b/igm, "状況");
v = v.replace(/\Backup Policies\b/igm, "バックアップポリシー");
v = v.replace(/\Locations\b/igm, "ロケーション");
v = v.replace(/\Subscription Plan\b/igm, "サブスクリプションプラン");
v = v.replace(/\Managed Workstations\b/igm, "管理下：ワークステーション");
v = v.replace(/\Managed Servers\b/igm, "管理下：サーバ");
v = v.replace(/\Cloud Repository Usage(%)\b/igm, "クラウドレポジトリ使用率（％）");
v = v.replace(/\Deleted Backup Recycle Bin\b/igm, "削除済みコミ箱：バックアップ");
v = v.replace(/\Back\b/igm, "戻る");
v = v.replace(/\Reset Password\b/igm, "パスワードを再設定");
v = v.replace(/\Email\b/igm, "メールアドレス");
v = v.replace(/\Reset\b/igm, "リセット");
v = v.replace(/\Username:\b/igm, "ユーザー名");
v = v.replace(/\Click Reset to receive an email to your mailbox with instructions for creating a new password.\b/igm, "パスワード再設定方法のメールをご確認ください");
v = v.replace(/\Latest Alarms\b/igm, "直近のアラーム");
v = v.replace(/\Capacity\b/igm, "割り当て容量");
v = v.replace(/\Free Space\b/igm, "残り容量");
v = v.replace(/\Used Space\b/igm, "利用済み容量");
v = v.replace(/\Cloud Repositories\b/igm, "クラウドレポジトリ数");
v = v.replace(/\Repositories\b/igm, "レポジトリ一覧");
v = v.replace(/\Hardware Plans Usage\b/igm, "ハードウェアプラン利用状況");
v = v.replace(/\Memory\b/igm, "メモリ");
v = v.replace(/\Storage\b/igm, "ストレージ");
v = v.replace(/\Health State\b/igm, "ヘルスステータス");
v = v.replace(/\Object\b/igm, "オブジェクト");
v = v.replace(/\Time\b/igm, "日時");
v = v.replace(/\Reseller\b/igm, "リセラー");
v = v.replace(/\Used Points\b/igm, "利用ポイント");
v = v.replace(/\Cloud Backup Resource Usage\b/igm, "クラウドバックアップ容量：利用状況");
v = v.replace(/\Managed Companies\b/igm, "管理中顧客");
v = v.replace(/\Hardware Plans Slots\b/igm, "ハードウェアプラン枠");
v = v.replace(/\Rule\b/igm, "ルール");
v = v.replace(/\Online\b/igm, "オンライン");
v = v.replace(/\Inaccessible\b/igm, "アクセス不可");
v = v.replace(/\Schedule\b/igm, "スケジュール");
v = v.replace(/\Last Run\b/igm, "最終実行");
v = v.replace(/\Next Run\b/igm, "次回実行");
v = v.replace(/\Discovered Computers\b/igm, "ディスカバリー済みコンピューター");
v = v.replace(/\Microsoft 365 Backup Servers\b/igm, "M365バックアップサーバ");
v = v.replace(/\Guest OS:\b/igm, "ゲストOS：");
v = v.replace(/\Total Computers\b/igm, "コンピュータ合計");
v = v.replace(/\View Discovered Computers\b/igm, "ディスカバリー済みコンピュータ：閲覧");
v = v.replace(/\Reset Discovered Computers\b/igm, "ディスカバリー済みコンピュータ：リセット");
v = v.replace(/\Backup Servers\b/igm, "バックアップサーバ");
v = v.replace(/\Activation\b/igm, "アクティベーション日時");
v = v.replace(/\Acknowledge Alarm\b/igm, "アラームを確認");
v = v.replace(/\All Time\b/igm, "全期間");
v = v.replace(/\Configurations\b/igm, "設定");
v = v.replace(/\View\b/igm, "ビュー");
v = v.replace(/\Send\b/igm, "送信");
v = v.replace(/\Generated On\b/igm, "生成日時");
v = v.replace(/\Run\b/igm, "実行");
v = v.replace(/\Report\b/igm, "レポート");
v = v.replace(/\Generated\b/igm, "生成済み");
v = v.replace(/\Invoice\b/igm, "請求書");
v = v.replace(/\Mark as Paid\b/igm, "フラグ：支払い済み");
v = v.replace(/\Mark as Unpaid\b/igm, "フラグ：未払い");
v = v.replace(/\Paid Date\b/igm, "支払い確認日");
v = v.replace(/\Due Date\b/igm, "支払い期限");

	
	textNode.nodeValue = v;
}
